package com.example.movies_nicolay_nacaro.models;

import com.example.movies_nicolay_nacaro.models.Movies;

import java.util.List;

public class MovieResponse {
    List<Movies> results;

    public List<Movies> getResults() {
        return results;
    }
}
